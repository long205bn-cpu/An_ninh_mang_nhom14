import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.io.File;
import java.nio.file.Files;
import java.util.Base64;

public class DESEncryptionApp extends JFrame {

    private JTextArea txtKeyEnc, txtPlaintext, txtCiphertextEnc;
    private JTextArea txtKeyDec, txtCiphertextDec, txtPlaintextDec;
    private JRadioButton rbHexEnc, rbBase64Enc, rbHexDec, rbBase64Dec;

    public DESEncryptionApp() {
        setTitle("DES ENCRYPTION - Application");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(2, 1, 10, 10));

        // Phần Mã Hóa
        add(createEncryptionPanel());
        // Phần Giải Mã
        add(createDecryptionPanel());
    }

    private JPanel createEncryptionPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE), "MÃ HÓA", TitledBorder.LEFT, TitledBorder.TOP, null, Color.BLUE));

        // Khóa bí mật
        JPanel pnlKey = new JPanel(new BorderLayout());
        pnlKey.add(new JLabel("Khóa bí mật:"), BorderLayout.NORTH);
        txtKeyEnc = new JTextArea(5, 15);
        txtKeyEnc.setLineWrap(true);
        pnlKey.add(new JScrollPane(txtKeyEnc), BorderLayout.CENTER);
        JButton btnGenerateKey = new JButton("Tạo khóa");
        btnGenerateKey.addActionListener(e -> generateKey());
        pnlKey.add(btnGenerateKey, BorderLayout.SOUTH);

        // Bản rõ
        JPanel pnlPlain = new JPanel(new BorderLayout());
        pnlPlain.add(new JLabel("Bản rõ:"), BorderLayout.NORTH);
        txtPlaintext = new JTextArea();
        txtPlaintext.setLineWrap(true);
        pnlPlain.add(new JScrollPane(txtPlaintext), BorderLayout.CENTER);

        JPanel pnlPlainBtns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnEncrypt = new JButton("Mã hóa");
        JButton btnOpenFile = new JButton("Mở file");
        pnlPlainBtns.add(btnEncrypt);
        pnlPlainBtns.add(btnOpenFile);
        pnlPlain.add(pnlPlainBtns, BorderLayout.SOUTH);

        // Bản mã
        JPanel pnlCipher = new JPanel(new BorderLayout());
        pnlCipher.add(new JLabel("Bản mã:"), BorderLayout.NORTH);
        txtCiphertextEnc = new JTextArea();
        txtCiphertextEnc.setLineWrap(true);
        pnlCipher.add(new JScrollPane(txtCiphertextEnc), BorderLayout.CENTER);

        JPanel pnlCipherBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnClear = new JButton("Xóa");
        JButton btnSaveFile = new JButton("Lưu File");
        pnlCipherBtns.add(btnClear);
        pnlCipherBtns.add(btnSaveFile);
        pnlCipher.add(pnlCipherBtns, BorderLayout.SOUTH);

        // Định dạng
        JPanel pnlFormat = new JPanel(new GridLayout(3, 1));
        pnlFormat.add(new JLabel("Định dạng đầu ra:"));
        rbHexEnc = new JRadioButton("HEX", true);
        rbBase64Enc = new JRadioButton("BASE64");
        ButtonGroup bgEnc = new ButtonGroup();
        bgEnc.add(rbHexEnc);
        bgEnc.add(rbBase64Enc);
        pnlFormat.add(rbHexEnc);
        pnlFormat.add(rbBase64Enc);
        pnlKey.add(pnlFormat, BorderLayout.EAST);

        // Layout tổng
        JPanel centerPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        centerPanel.add(pnlPlain);
        centerPanel.add(pnlCipher);

        panel.add(pnlKey, BorderLayout.WEST);
        panel.add(centerPanel, BorderLayout.CENTER);

        // Events
        btnEncrypt.addActionListener(e -> encryptData());
        btnClear.addActionListener(e -> { txtPlaintext.setText(""); txtCiphertextEnc.setText(""); });
        btnOpenFile.addActionListener(e -> openTextFile(txtPlaintext));
        btnSaveFile.addActionListener(e -> saveTextFile(txtCiphertextEnc));

        return panel;
    }

    private JPanel createDecryptionPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE), "GIẢI MÃ", TitledBorder.LEFT, TitledBorder.TOP, null, Color.BLUE));

        // Khóa bí mật
        JPanel pnlKey = new JPanel(new BorderLayout());
        pnlKey.add(new JLabel("Khóa bí mật:"), BorderLayout.NORTH);
        txtKeyDec = new JTextArea(5, 15);
        txtKeyDec.setLineWrap(true);
        pnlKey.add(new JScrollPane(txtKeyDec), BorderLayout.CENTER);

        // Bản mã đầu vào
        JPanel pnlCipher = new JPanel(new BorderLayout());
        pnlCipher.add(new JLabel("Bản mã:"), BorderLayout.NORTH);
        txtCiphertextDec = new JTextArea();
        txtCiphertextDec.setLineWrap(true);
        pnlCipher.add(new JScrollPane(txtCiphertextDec), BorderLayout.CENTER);

        JPanel pnlCipherBtns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnDecrypt = new JButton("Giải mã");
        JButton btnOpenFile = new JButton("Mở File");
        pnlCipherBtns.add(btnDecrypt);
        pnlCipherBtns.add(btnOpenFile);
        pnlCipher.add(pnlCipherBtns, BorderLayout.SOUTH);

        // Bản rõ đầu ra
        JPanel pnlPlain = new JPanel(new BorderLayout());
        pnlPlain.add(new JLabel("Bản rõ:"), BorderLayout.NORTH);
        txtPlaintextDec = new JTextArea();
        txtPlaintextDec.setLineWrap(true);
        pnlPlain.add(new JScrollPane(txtPlaintextDec), BorderLayout.CENTER);

        JPanel pnlPlainBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnClear = new JButton("Xóa");
        JButton btnSaveFile = new JButton("Lưu File");
        pnlPlainBtns.add(btnClear);
        pnlPlainBtns.add(btnSaveFile);
        pnlPlain.add(pnlPlainBtns, BorderLayout.SOUTH);

        // Định dạng
        JPanel pnlFormat = new JPanel(new GridLayout(3, 1));
        pnlFormat.add(new JLabel("Định dạng đầu vào:"));
        rbHexDec = new JRadioButton("HEX", true);
        rbBase64Dec = new JRadioButton("BASE64");
        ButtonGroup bgDec = new ButtonGroup();
        bgDec.add(rbHexDec);
        bgDec.add(rbBase64Dec);
        pnlFormat.add(rbHexDec);
        pnlFormat.add(rbBase64Dec);
        pnlKey.add(pnlFormat, BorderLayout.EAST);

        // Layout tổng
        JPanel centerPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        centerPanel.add(pnlCipher);
        centerPanel.add(pnlPlain);

        panel.add(pnlKey, BorderLayout.WEST);
        panel.add(centerPanel, BorderLayout.CENTER);

        // Events
        btnDecrypt.addActionListener(e -> decryptData());
        btnClear.addActionListener(e -> { txtCiphertextDec.setText(""); txtPlaintextDec.setText(""); });
        btnOpenFile.addActionListener(e -> openTextFile(txtCiphertextDec));
        btnSaveFile.addActionListener(e -> saveTextFile(txtPlaintextDec));

        return panel;
    }

    private void generateKey() {
        try {
            KeyGenerator keyGen = KeyGenerator.getInstance("DES");
            SecretKey secretKey = keyGen.generateKey();
            String hexKey = bytesToHex(secretKey.getEncoded());
            txtKeyEnc.setText(hexKey.toUpperCase());
            txtKeyDec.setText(hexKey.toUpperCase());
            JOptionPane.showMessageDialog(this, "Khóa đã được tạo thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void encryptData() {
        String key = txtKeyEnc.getText().trim();
        String plainText = txtPlaintext.getText();

        if (plainText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập bản rõ!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (key.length() != 16) { 
            JOptionPane.showMessageDialog(this, "Khóa không hợp lệ! Vui lòng kiểm tra lại độ dài khóa!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
            SecretKeySpec secretKey = new SecretKeySpec(hexToBytes(key), "DES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedBytes = cipher.doFinal(plainText.getBytes("UTF-8"));

            if (rbHexEnc.isSelected()) {
                txtCiphertextEnc.setText(bytesToHex(encryptedBytes).toUpperCase());
            } else {
                txtCiphertextEnc.setText(Base64.getEncoder().encodeToString(encryptedBytes));
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi mã hóa: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void decryptData() {
        String key = txtKeyDec.getText().trim();
        String cipherText = txtCiphertextDec.getText().trim();

        if (key.length() != 16) {
            JOptionPane.showMessageDialog(this, "Khóa bị thay đổi! Vui lòng kiểm tra lại kích thước và nội dung khóa!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            byte[] cipherBytes;
            if (rbHexDec.isSelected()) {
                cipherBytes = hexToBytes(cipherText);
            } else {
                cipherBytes = Base64.getDecoder().decode(cipherText);
            }

            Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
            SecretKeySpec secretKey = new SecretKeySpec(hexToBytes(key), "DES");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            
            byte[] decryptedBytes = cipher.doFinal(cipherBytes);
            txtPlaintextDec.setText(new String(decryptedBytes, "UTF-8"));
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Dữ liệu không toàn vẹn! Lỗi giải mã: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openTextFile(JTextArea targetArea) {
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                File file = fileChooser.getSelectedFile();
                String content = new String(Files.readAllBytes(file.toPath()), "UTF-8");
                targetArea.setText(content);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Không thể đọc file!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void saveTextFile(JTextArea sourceArea) {
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                File file = fileChooser.getSelectedFile();
                Files.write(file.toPath(), sourceArea.getText().getBytes("UTF-8"));
                JOptionPane.showMessageDialog(this, "Lưu file thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Không thể lưu file!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Helper methods for HEX conversions
    private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }

    public static byte[] hexToBytes(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                                 + Character.digit(s.charAt(i+1), 16));
        }
        return data;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) { e.printStackTrace(); }
            new DESEncryptionApp().setVisible(true);
        });
    }
}