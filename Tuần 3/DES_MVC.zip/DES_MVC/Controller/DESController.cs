﻿using System;
using System.Windows.Forms;
using DES_MVC.Model;

namespace DES_MVC.Controller
{
    public class DESController
    {
        private DESModel model;
        private Form1 view;

        public DESController(DESModel model, Form1 view)
        {
            this.model = model;
            this.view = view;

            view.btnGenerateKey.Click += GenerateKey;
            view.btnEncrypt.Click += Encrypt;
            view.btnDecrypt.Click += Decrypt;
        }

        private void GenerateKey(object sender, EventArgs e)
        {
            string key = model.GenerateKey();

            view.txtKeyEncrypt.Text = key;
            view.txtKeyDecrypt.Text = key;

            MessageBox.Show("Tạo khóa thành công!");
        }

        private void Encrypt(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(view.txtPlainText.Text))
            {
                MessageBox.Show("Bản rõ không được để trống!", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; 
            }

            if (string.IsNullOrWhiteSpace(view.txtKeyEncrypt.Text))
            {
                MessageBox.Show("Vui lòng tạo hoặc nhập khóa bí mật trước khi mã hóa!", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string result = model.Encrypt(
                    view.txtPlainText.Text,
                    view.txtKeyEncrypt.Text);

                view.txtCipherText.Text = result;
            }
            catch
            {
                MessageBox.Show("Lỗi mã hóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Decrypt(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(view.txtCipherTextDecrypt.Text)) 
            {
                MessageBox.Show("Bản mã không được để trống!", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrWhiteSpace(view.txtKeyDecrypt.Text))
            {
                MessageBox.Show("Khóa bí mật phần giải mã không được để trống!", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (view.txtKeyDecrypt.Text.Length < 8)
            {
                MessageBox.Show("Khóa bí mật không hợp lệ hoặc đã bị chỉnh sửa sai cấu trúc!", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                string result = model.Decrypt(
                    view.txtCipherTextDecrypt.Text,
                    view.txtKeyDecrypt.Text);

                view.txtPlainTextDecrypt.Text = result;
            }
            catch
            {
                MessageBox.Show("Lỗi giải mã! Khóa bí mật đã bị thay đổi hoặc không chính xác.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}