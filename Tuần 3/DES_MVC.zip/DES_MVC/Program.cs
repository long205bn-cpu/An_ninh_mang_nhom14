﻿using System;
using System.Windows.Forms;
using DES_MVC.Model;
using DES_MVC.Controller;

namespace DES_MVC
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            DESModel model = new DESModel();
            Form1 view = new Form1();

            DESController controller =
                new DESController(model, view);

            Application.Run(view);
        }
    }
}