﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace DES_MVC.Model
{
    public class DESModel
    {
        public string GenerateKey()
        {
            using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
            {
                des.GenerateKey();
                return BitConverter.ToString(des.Key).Replace("-", "");
            }
        }

        public string Encrypt(string plainText, string keyHex)
        {
            byte[] key = HexToBytes(keyHex);

            using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
            {
                des.Key = key;
                des.Mode = CipherMode.ECB;
                des.Padding = PaddingMode.PKCS7;

                byte[] data = Encoding.UTF8.GetBytes(plainText);

                byte[] result = des.CreateEncryptor()
                                   .TransformFinalBlock(data, 0, data.Length);

                return Convert.ToBase64String(result);
            }
        }

        public string Decrypt(string cipherText, string keyHex)
        {
            byte[] key = HexToBytes(keyHex);

            using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
            {
                des.Key = key;
                des.Mode = CipherMode.ECB;
                des.Padding = PaddingMode.PKCS7;

                byte[] data = Convert.FromBase64String(cipherText);

                byte[] result = des.CreateDecryptor()
                                   .TransformFinalBlock(data, 0, data.Length);

                return Encoding.UTF8.GetString(result);
            }
        }

        private byte[] HexToBytes(string hex)
        {
            byte[] bytes = new byte[hex.Length / 2];

            for (int i = 0; i < bytes.Length; i++)
            {
                bytes[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);
            }

            return bytes;
        }
    }
}