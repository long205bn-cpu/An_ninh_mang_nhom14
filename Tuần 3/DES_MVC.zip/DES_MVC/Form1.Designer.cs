﻿namespace DES_MVC
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtKeyEncrypt = new System.Windows.Forms.TextBox();
            this.btnGenerateKey = new System.Windows.Forms.Button();
            this.rbHexEncrypt = new System.Windows.Forms.RadioButton();
            this.rbBase64Encrypt = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnClearEncrypt = new System.Windows.Forms.Button();
            this.btnSaveFileEncrypt = new System.Windows.Forms.Button();
            this.btnOpenFileEncrypt = new System.Windows.Forms.Button();
            this.btnEncrypt = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtKeyDecrypt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.rbHexDecrypt = new System.Windows.Forms.RadioButton();
            this.rbBase64Decrypt = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnDecrypt = new System.Windows.Forms.Button();
            this.btnOpenFileDecrypt = new System.Windows.Forms.Button();
            this.btnClearDecrypt = new System.Windows.Forms.Button();
            this.btnSaveFileDecrypt = new System.Windows.Forms.Button();
            this.txtPlainText = new System.Windows.Forms.RichTextBox();
            this.txtCipherText = new System.Windows.Forms.RichTextBox();
            this.txtCipherTextDecrypt = new System.Windows.Forms.RichTextBox();
            this.txtPlainTextDecrypt = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(144, 117);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "MÃ HÓA";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(897, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "GIẢI MÃ";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Khóa bí mật";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(583, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "DES";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtKeyEncrypt
            // 
            this.txtKeyEncrypt.Location = new System.Drawing.Point(48, 219);
            this.txtKeyEncrypt.Name = "txtKeyEncrypt";
            this.txtKeyEncrypt.Size = new System.Drawing.Size(255, 22);
            this.txtKeyEncrypt.TabIndex = 5;
            this.txtKeyEncrypt.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnGenerateKey
            // 
            this.btnGenerateKey.Location = new System.Drawing.Point(326, 211);
            this.btnGenerateKey.Name = "btnGenerateKey";
            this.btnGenerateKey.Size = new System.Drawing.Size(89, 38);
            this.btnGenerateKey.TabIndex = 6;
            this.btnGenerateKey.Text = "Tạo khóa";
            this.btnGenerateKey.UseVisualStyleBackColor = true;
            // 
            // rbHexEncrypt
            // 
            this.rbHexEncrypt.AutoSize = true;
            this.rbHexEncrypt.Location = new System.Drawing.Point(48, 322);
            this.rbHexEncrypt.Name = "rbHexEncrypt";
            this.rbHexEncrypt.Size = new System.Drawing.Size(55, 20);
            this.rbHexEncrypt.TabIndex = 7;
            this.rbHexEncrypt.TabStop = true;
            this.rbHexEncrypt.Text = "HEX";
            this.rbHexEncrypt.UseVisualStyleBackColor = true;
            // 
            // rbBase64Encrypt
            // 
            this.rbBase64Encrypt.AutoSize = true;
            this.rbBase64Encrypt.Location = new System.Drawing.Point(48, 348);
            this.rbBase64Encrypt.Name = "rbBase64Encrypt";
            this.rbBase64Encrypt.Size = new System.Drawing.Size(78, 20);
            this.rbBase64Encrypt.TabIndex = 8;
            this.rbBase64Encrypt.TabStop = true;
            this.rbBase64Encrypt.Text = "BASE64";
            this.rbBase64Encrypt.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(48, 396);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Bản rõ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(48, 292);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 16);
            this.label7.TabIndex = 11;
            this.label7.Text = "Định dạng đầu ra";
            // 
            // btnClearEncrypt
            // 
            this.btnClearEncrypt.Location = new System.Drawing.Point(245, 588);
            this.btnClearEncrypt.Name = "btnClearEncrypt";
            this.btnClearEncrypt.Size = new System.Drawing.Size(75, 28);
            this.btnClearEncrypt.TabIndex = 12;
            this.btnClearEncrypt.Text = "Xóa";
            this.btnClearEncrypt.UseVisualStyleBackColor = true;
            // 
            // btnSaveFileEncrypt
            // 
            this.btnSaveFileEncrypt.Location = new System.Drawing.Point(326, 588);
            this.btnSaveFileEncrypt.Name = "btnSaveFileEncrypt";
            this.btnSaveFileEncrypt.Size = new System.Drawing.Size(75, 28);
            this.btnSaveFileEncrypt.TabIndex = 13;
            this.btnSaveFileEncrypt.Text = "Lưu File";
            this.btnSaveFileEncrypt.UseVisualStyleBackColor = true;
            // 
            // btnOpenFileEncrypt
            // 
            this.btnOpenFileEncrypt.Location = new System.Drawing.Point(109, 588);
            this.btnOpenFileEncrypt.Name = "btnOpenFileEncrypt";
            this.btnOpenFileEncrypt.Size = new System.Drawing.Size(75, 28);
            this.btnOpenFileEncrypt.TabIndex = 14;
            this.btnOpenFileEncrypt.Text = "Mở File";
            this.btnOpenFileEncrypt.UseVisualStyleBackColor = true;
            // 
            // btnEncrypt
            // 
            this.btnEncrypt.Location = new System.Drawing.Point(19, 588);
            this.btnEncrypt.Name = "btnEncrypt";
            this.btnEncrypt.Size = new System.Drawing.Size(75, 28);
            this.btnEncrypt.TabIndex = 15;
            this.btnEncrypt.Text = "Mã hóa";
            this.btnEncrypt.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(265, 396);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 16);
            this.label8.TabIndex = 16;
            this.label8.Text = "Bản mã";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(722, 190);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 16);
            this.label9.TabIndex = 18;
            this.label9.Text = "Khóa bí mật";
            // 
            // txtKeyDecrypt
            // 
            this.txtKeyDecrypt.Location = new System.Drawing.Point(726, 219);
            this.txtKeyDecrypt.Name = "txtKeyDecrypt";
            this.txtKeyDecrypt.Size = new System.Drawing.Size(303, 22);
            this.txtKeyDecrypt.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(722, 292);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 16);
            this.label4.TabIndex = 20;
            this.label4.Text = "Định dạng đầu ra";
            // 
            // rbHexDecrypt
            // 
            this.rbHexDecrypt.AutoSize = true;
            this.rbHexDecrypt.Location = new System.Drawing.Point(773, 322);
            this.rbHexDecrypt.Name = "rbHexDecrypt";
            this.rbHexDecrypt.Size = new System.Drawing.Size(55, 20);
            this.rbHexDecrypt.TabIndex = 21;
            this.rbHexDecrypt.TabStop = true;
            this.rbHexDecrypt.Text = "HEX";
            this.rbHexDecrypt.UseVisualStyleBackColor = true;
            // 
            // rbBase64Decrypt
            // 
            this.rbBase64Decrypt.AutoSize = true;
            this.rbBase64Decrypt.Location = new System.Drawing.Point(773, 348);
            this.rbBase64Decrypt.Name = "rbBase64Decrypt";
            this.rbBase64Decrypt.Size = new System.Drawing.Size(78, 20);
            this.rbBase64Decrypt.TabIndex = 22;
            this.rbBase64Decrypt.TabStop = true;
            this.rbBase64Decrypt.Text = "BASE64";
            this.rbBase64Decrypt.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(723, 396);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 16);
            this.label10.TabIndex = 23;
            this.label10.Text = "Bản mã";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(975, 396);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 16);
            this.label11.TabIndex = 24;
            this.label11.Text = "Bản rõ";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // btnDecrypt
            // 
            this.btnDecrypt.Location = new System.Drawing.Point(677, 588);
            this.btnDecrypt.Name = "btnDecrypt";
            this.btnDecrypt.Size = new System.Drawing.Size(75, 28);
            this.btnDecrypt.TabIndex = 27;
            this.btnDecrypt.Text = "Giải mã";
            this.btnDecrypt.UseVisualStyleBackColor = true;
            // 
            // btnOpenFileDecrypt
            // 
            this.btnOpenFileDecrypt.Location = new System.Drawing.Point(773, 588);
            this.btnOpenFileDecrypt.Name = "btnOpenFileDecrypt";
            this.btnOpenFileDecrypt.Size = new System.Drawing.Size(75, 28);
            this.btnOpenFileDecrypt.TabIndex = 28;
            this.btnOpenFileDecrypt.Text = "Mở File";
            this.btnOpenFileDecrypt.UseVisualStyleBackColor = true;
            // 
            // btnClearDecrypt
            // 
            this.btnClearDecrypt.Location = new System.Drawing.Point(953, 588);
            this.btnClearDecrypt.Name = "btnClearDecrypt";
            this.btnClearDecrypt.Size = new System.Drawing.Size(75, 28);
            this.btnClearDecrypt.TabIndex = 29;
            this.btnClearDecrypt.Text = "Xóa";
            this.btnClearDecrypt.UseVisualStyleBackColor = true;
            // 
            // btnSaveFileDecrypt
            // 
            this.btnSaveFileDecrypt.Location = new System.Drawing.Point(1034, 588);
            this.btnSaveFileDecrypt.Name = "btnSaveFileDecrypt";
            this.btnSaveFileDecrypt.Size = new System.Drawing.Size(75, 28);
            this.btnSaveFileDecrypt.TabIndex = 30;
            this.btnSaveFileDecrypt.Text = "Lưu File";
            this.btnSaveFileDecrypt.UseVisualStyleBackColor = true;
            // 
            // txtPlainText
            // 
            this.txtPlainText.Location = new System.Drawing.Point(48, 423);
            this.txtPlainText.Name = "txtPlainText";
            this.txtPlainText.Size = new System.Drawing.Size(155, 139);
            this.txtPlainText.TabIndex = 31;
            this.txtPlainText.Text = "";
            // 
            // txtCipherText
            // 
            this.txtCipherText.Location = new System.Drawing.Point(245, 426);
            this.txtCipherText.Name = "txtCipherText";
            this.txtCipherText.Size = new System.Drawing.Size(170, 136);
            this.txtCipherText.TabIndex = 32;
            this.txtCipherText.Text = "";
            // 
            // txtCipherTextDecrypt
            // 
            this.txtCipherTextDecrypt.Location = new System.Drawing.Point(725, 423);
            this.txtCipherTextDecrypt.Name = "txtCipherTextDecrypt";
            this.txtCipherTextDecrypt.Size = new System.Drawing.Size(170, 139);
            this.txtCipherTextDecrypt.TabIndex = 33;
            this.txtCipherTextDecrypt.Text = "";
            // 
            // txtPlainTextDecrypt
            // 
            this.txtPlainTextDecrypt.Location = new System.Drawing.Point(978, 423);
            this.txtPlainTextDecrypt.Name = "txtPlainTextDecrypt";
            this.txtPlainTextDecrypt.Size = new System.Drawing.Size(172, 139);
            this.txtPlainTextDecrypt.TabIndex = 34;
            this.txtPlainTextDecrypt.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1213, 671);
            this.Controls.Add(this.txtPlainTextDecrypt);
            this.Controls.Add(this.txtCipherTextDecrypt);
            this.Controls.Add(this.txtCipherText);
            this.Controls.Add(this.txtPlainText);
            this.Controls.Add(this.btnSaveFileDecrypt);
            this.Controls.Add(this.btnClearDecrypt);
            this.Controls.Add(this.btnOpenFileDecrypt);
            this.Controls.Add(this.btnDecrypt);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.rbBase64Decrypt);
            this.Controls.Add(this.rbHexDecrypt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtKeyDecrypt);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnEncrypt);
            this.Controls.Add(this.btnOpenFileEncrypt);
            this.Controls.Add(this.btnSaveFileEncrypt);
            this.Controls.Add(this.btnClearEncrypt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.rbBase64Encrypt);
            this.Controls.Add(this.rbHexEncrypt);
            this.Controls.Add(this.btnGenerateKey);
            this.Controls.Add(this.txtKeyEncrypt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton rbHexEncrypt;
        private System.Windows.Forms.RadioButton rbBase64Encrypt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnClearEncrypt;
        private System.Windows.Forms.Button btnSaveFileEncrypt;
        private System.Windows.Forms.Button btnOpenFileEncrypt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rbHexDecrypt;
        private System.Windows.Forms.RadioButton rbBase64Decrypt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnOpenFileDecrypt;
        private System.Windows.Forms.Button btnClearDecrypt;
        private System.Windows.Forms.Button btnSaveFileDecrypt;
        public System.Windows.Forms.Button btnGenerateKey;
        public System.Windows.Forms.Button btnEncrypt;
        public System.Windows.Forms.TextBox txtKeyDecrypt;
        public System.Windows.Forms.RichTextBox txtCipherTextDecrypt;
        public System.Windows.Forms.RichTextBox txtPlainTextDecrypt;
        public System.Windows.Forms.TextBox txtKeyEncrypt;
        public System.Windows.Forms.RichTextBox txtPlainText;
        public System.Windows.Forms.RichTextBox txtCipherText;
        public System.Windows.Forms.Button btnDecrypt;
    }
}

