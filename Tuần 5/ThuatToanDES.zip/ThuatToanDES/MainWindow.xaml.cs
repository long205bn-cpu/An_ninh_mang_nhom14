﻿using Microsoft.Win32;
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows;

namespace ThuatToanDES
{
    public partial class MainWindow : Window
    {
        private DESAlgorithm des = new DESAlgorithm();

        private ObservableCollection<ActionHistory> histories =
            new ObservableCollection<ActionHistory>();

        private int historyIndex = 1;

        public MainWindow()
        {
            InitializeComponent();

            dgHistory.ItemsSource = histories;

            txtStatus.Text = "Sẵn sàng";
            txtTime.Text = "Thời gian: 0 ms";
        }
        private string GenerateRandomKey()
        {
            byte[] key = new byte[8];

            RandomNumberGenerator.Fill(key);

            return BitConverter
                .ToString(key)
                .Replace("-", "");
        }
        private void btnGenerateKey_Click(
    object sender,
    RoutedEventArgs e)
        {
            string key = GenerateRandomKey();

            txtEncryptKey.Text = key;
            txtDecryptKey.Text = key;

            MessageBox.Show(
                "Đã sinh khóa DES thành công!",
                "Thông báo",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        // ==========================
        // MÃ HÓA
        // ==========================
        private void btnEncrypt_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtEncryptInput.Text))
                {
                    MessageBox.Show("Vui lòng nhập dữ liệu cần mã hóa!");
                    return;
                }

                Stopwatch sw = Stopwatch.StartNew();

                DateTime start = DateTime.Now;

                string cipher =
                    des.Encrypt(
                        txtEncryptInput.Text,
                        txtEncryptKey.Text);

                sw.Stop();

                txtEncryptOutput.Text = cipher;

                txtStatus.Text = "Đang thực hiện mã hóa";

                txtTime.Text =
                    $"Thời gian: {sw.ElapsedMilliseconds} ms";

                histories.Add(
                    new ActionHistory
                    {
                        STT = historyIndex++,
                        Action = "Mã hóa",
                        StartTime =
                            start.ToString(
                                "dd/MM/yyyy HH:mm:ss"),
                        Duration =
                            sw.ElapsedMilliseconds + " ms",
                        DataLength =
                            txtEncryptInput.Text.Length,
                        Status = "Thành công"
                    });

                MessageBox.Show(
                    "Mã hóa thành công!",
                    "Thông báo");
            }
            catch (Exception)
            {
                txtStatus.Text = "Mã hóa không thành công";

                txtTime.Text = "Thời gian: 0 ms";

                histories.Add(
                    new ActionHistory
                    {
                        STT = historyIndex++,
                        Action = "Mã hóa",
                        StartTime = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"),
                        Duration = "0 ms",
                        DataLength = txtEncryptInput.Text.Length,
                        Status = "Không thành công"
                    });

                MessageBox.Show(
                    "Mã hóa không thành công!",
                    "Lỗi mã hóa",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // ==========================
        // GIẢI MÃ
        // ==========================
        private void btnDecrypt_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtDecryptInput.Text))
                {
                    MessageBox.Show("Vui lòng nhập bản mã!");
                    return;
                }

                Stopwatch sw = Stopwatch.StartNew();

                DateTime start = DateTime.Now;

                string plain =
                    des.Decrypt(
                        txtDecryptInput.Text,
                        txtDecryptKey.Text);

                sw.Stop();

                txtDecryptOutput.Text = plain;

                txtStatus.Text = "Đang thực hiện giải mã";

                txtTime.Text =
                    $"Thời gian: {sw.ElapsedMilliseconds} ms";

                histories.Add(
                    new ActionHistory
                    {
                        STT = historyIndex++,
                        Action = "Giải mã",
                        StartTime =
                            start.ToString(
                                "dd/MM/yyyy HH:mm:ss"),
                        Duration =
                            sw.ElapsedMilliseconds + " ms",
                        DataLength =
                            txtDecryptInput.Text.Length,
                        Status = "Thành công"
                    });

                MessageBox.Show(
                    "Giải mã thành công!",
                    "Thông báo");
            }
            catch (Exception)
            {
                txtStatus.Text = "Mã hóa không thành công";

                txtTime.Text = "Thời gian: 0 ms";

                histories.Add(
                    new ActionHistory
                    {
                        STT = historyIndex++,
                        Action = "Mã hóa",
                        StartTime = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"),
                        Duration = "0 ms",
                        DataLength = txtEncryptInput.Text.Length,
                        Status = "Không thành công"
                    });

                MessageBox.Show(
                    "Mã hóa không thành công!",
                    "Lỗi mã hóa",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }
        private void btnOpenEncryptFile_Click(
    object sender,
    RoutedEventArgs e)
        {
            OpenFileDialog dlg =
                new OpenFileDialog();

            dlg.Filter =
                "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";

            if (dlg.ShowDialog() == true)
            {
                txtEncryptInput.Text =
                    File.ReadAllText(
                        dlg.FileName,
                        Encoding.UTF8);
            }
        }
        private void btnOpenDecryptFile_Click(
    object sender,
    RoutedEventArgs e)
        {
            OpenFileDialog dlg =
                new OpenFileDialog();

            dlg.Filter =
                "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";

            if (dlg.ShowDialog() == true)
            {
                txtDecryptInput.Text =
                    File.ReadAllText(
                        dlg.FileName,
                        Encoding.UTF8);
            }
        }
        private void btnOpenKey_Click(
    object sender,
    RoutedEventArgs e)
        {
            OpenFileDialog dlg =
                new OpenFileDialog();

            dlg.Filter =
                "Text Files (*.txt)|*.txt";

            if (dlg.ShowDialog() == true)
            {
                string key =
                    File.ReadAllText(
                        dlg.FileName,
                        Encoding.UTF8);

                txtEncryptKey.Text =
                    key.Trim();

                txtDecryptKey.Text =
                    key.Trim();
            }
        }
        private void btnSaveEncrypt_Click(
    object sender,
    RoutedEventArgs e)
        {
            SaveFileDialog dlg =
                new SaveFileDialog();

            dlg.Filter =
                "Text Files (*.txt)|*.txt";

            dlg.FileName = "BanMa.txt";

            if (dlg.ShowDialog() == true)
            {
                File.WriteAllText(
                    dlg.FileName,
                    txtEncryptOutput.Text,
                    Encoding.UTF8);
            }
        }
        private void btnSaveDecrypt_Click(
    object sender,
    RoutedEventArgs e)
        {
            SaveFileDialog dlg =
                new SaveFileDialog();

            dlg.Filter =
                "Text Files (*.txt)|*.txt";

            dlg.FileName = "BanRo.txt";

            if (dlg.ShowDialog() == true)
            {
                File.WriteAllText(
                    dlg.FileName,
                    txtDecryptOutput.Text,
                    Encoding.UTF8);
            }
        }
        private void btnSaveKey_Click(
    object sender,
    RoutedEventArgs e)
        {
            SaveFileDialog dlg =
                new SaveFileDialog();

            dlg.Filter =
                "Text Files (*.txt)|*.txt";

            dlg.FileName = "DES_Key.txt";

            if (dlg.ShowDialog() == true)
            {
                File.WriteAllText(
                    dlg.FileName,
                    txtEncryptKey.Text,
                    Encoding.UTF8);
            }
        }
        private void btnClear_Click(
    object sender,
    RoutedEventArgs e)
        {
            txtEncryptInput.Clear();
            txtEncryptOutput.Clear();

            txtDecryptInput.Clear();
            txtDecryptOutput.Clear();

            txtEncryptKey.Clear();
            txtDecryptKey.Clear();

            txtStatus.Text = "Sẵn sàng";
            txtTime.Text = "Thời gian: 0 ms";
        }
    }
}