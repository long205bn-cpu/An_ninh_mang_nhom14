﻿using System;

namespace ThuatToanDES
{
    public class ActionHistory
    {
        public int STT { get; set; }

        // Mã hóa hoặc Giải mã
        public string Action { get; set; }

        // Thời điểm bắt đầu
        public string StartTime { get; set; }

        // Thời gian xử lý
        public string Duration { get; set; }

        // Độ dài dữ liệu
        public int DataLength { get; set; }

        // Trạng thái
        public string Status { get; set; }
    }
}