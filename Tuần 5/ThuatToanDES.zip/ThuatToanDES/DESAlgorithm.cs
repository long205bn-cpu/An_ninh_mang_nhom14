﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace ThuatToanDES
{
    public class DESAlgorithm
    {
        public List<DESRound> Rounds = new();

        private byte[] HexToBytes(string hex)
        {
            if (hex.Length != 16)
                throw new Exception(
                    "Khóa DES phải gồm đúng 16 ký tự HEX.");

            byte[] bytes = new byte[8];

            for (int i = 0; i < 8; i++)
            {
                bytes[i] =
                    Convert.ToByte(
                        hex.Substring(i * 2, 2),
                        16);
            }

            return bytes;
        }

        public string Encrypt(string text, string key)
        {
            Rounds.Clear();

            for (int i = 1; i <= 16; i++)
            {
                Rounds.Add(new DESRound
                {
                    Round = i,
                    Left = $"L{i - 1}",
                    Right = $"R{i - 1}",
                    RoundKey = $"K{i}",
                    FunctionResult = $"f(R{i - 1},K{i})"
                });
            }

            byte[] keyBytes = HexToBytes(key);

            using (DESCryptoServiceProvider des =
                   new DESCryptoServiceProvider())
            {
                des.Key = keyBytes;
                des.IV = keyBytes;

                byte[] data =
                    Encoding.UTF8.GetBytes(text);

                ICryptoTransform encryptor =
                    des.CreateEncryptor();

                byte[] result =
                    encryptor.TransformFinalBlock(
                        data,
                        0,
                        data.Length);

                return Convert.ToBase64String(result);
            }
        }

        public string Decrypt(string cipher, string key)
        {
            byte[] keyBytes = HexToBytes(key);

            using (DESCryptoServiceProvider des =
                   new DESCryptoServiceProvider())
            {
                des.Key = keyBytes;
                des.IV = keyBytes;

                byte[] data =
                    Convert.FromBase64String(cipher);

                ICryptoTransform decryptor =
                    des.CreateDecryptor();

                byte[] result =
                    decryptor.TransformFinalBlock(
                        data,
                        0,
                        data.Length);

                return Encoding.UTF8.GetString(result);
            }
        }
    }
}