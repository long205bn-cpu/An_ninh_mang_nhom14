import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.io.File;
import java.nio.file.Files;
import java.util.Base64;

public class DESEncryptionApp extends JFrame {

    private JTextArea txtKeyEnc, txtPlaintext, txtCiphertextEnc;
    private JTextArea txtKeyDec, txtCiphertextDec, txtPlaintextDec;
    private JRadioButton rbHexEnc, rbBase64Enc, rbHexDec, rbBase64Dec;

    public DESEncryptionApp() {
        setTitle("DES ENCRYPTION - Application");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(2, 1, 10, 10));

        // Phần Mã Hóa
        add(createEncryptionPanel());
        // Phần Giải Mã
        add(createDecryptionPanel());
    }

    private JPanel createEncryptionPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE), "MÃ HÓA", TitledBorder.LEFT, TitledBorder.TOP, null, Color.BLUE));

        // Khóa bí mật
        JPanel pnlKey = new JPanel(new BorderLayout());
        pnlKey.add(new JLabel("Khóa bí mật:"), BorderLayout.NORTH);
        txtKeyEnc = new JTextArea(5, 15);
        txtKeyEnc.setLineWrap(true);
        pnlKey.add(new JScrollPane(txtKeyEnc), BorderLayout.CENTER);
        JButton btnGenerateKey = new JButton("Tạo khóa");
        btnGenerateKey.addActionListener(e -> generateKey());
        pnlKey.add(btnGenerateKey, BorderLayout.SOUTH);

        // Bản rõ
        JPanel pnlPlain = new JPanel(new BorderLayout());
        pnlPlain.add(new JLabel("Bản rõ (Nhập Text):"), BorderLayout.NORTH);
        txtPlaintext = new JTextArea();
        txtPlaintext.setLineWrap(true);
        pnlPlain.add(new JScrollPane(txtPlaintext), BorderLayout.CENTER);

        JPanel pnlPlainBtns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnEncryptText = new JButton("Mã hóa Text");
        JButton btnEncryptFile = new JButton("Mã hóa File"); // NÚT MỚI
        pnlPlainBtns.add(btnEncryptText);
        pnlPlainBtns.add(btnEncryptFile);
        pnlPlain.add(pnlPlainBtns, BorderLayout.SOUTH);

        // Bản mã
        JPanel pnlCipher = new JPanel(new BorderLayout());
        pnlCipher.add(new JLabel("Bản mã:"), BorderLayout.NORTH);
        txtCiphertextEnc = new JTextArea();
        txtCiphertextEnc.setLineWrap(true);
        pnlCipher.add(new JScrollPane(txtCiphertextEnc), BorderLayout.CENTER);

        JPanel pnlCipherBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnClear = new JButton("Xóa");
        JButton btnSaveFile = new JButton("Lưu Text");
        pnlCipherBtns.add(btnClear);
        pnlCipherBtns.add(btnSaveFile);
        pnlCipher.add(pnlCipherBtns, BorderLayout.SOUTH);

        // Định dạng
        JPanel pnlFormat = new JPanel(new GridLayout(3, 1));
        pnlFormat.add(new JLabel("Định dạng đầu ra:"));
        rbHexEnc = new JRadioButton("HEX", true);
        rbBase64Enc = new JRadioButton("BASE64");
        ButtonGroup bgEnc = new ButtonGroup();
        bgEnc.add(rbHexEnc);
        bgEnc.add(rbBase64Enc);
        pnlFormat.add(rbHexEnc);
        pnlFormat.add(rbBase64Enc);
        pnlKey.add(pnlFormat, BorderLayout.EAST);

        // Layout tổng
        JPanel centerPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        centerPanel.add(pnlPlain);
        centerPanel.add(pnlCipher);

        panel.add(pnlKey, BorderLayout.WEST);
        panel.add(centerPanel, BorderLayout.CENTER);

        // Events
        btnEncryptText.addActionListener(e -> encryptText());
        btnEncryptFile.addActionListener(e -> processFile(Cipher.ENCRYPT_MODE, txtKeyEnc.getText().trim()));
        btnClear.addActionListener(e -> { txtPlaintext.setText(""); txtCiphertextEnc.setText(""); });
        btnSaveFile.addActionListener(e -> saveTextFile(txtCiphertextEnc));

        return panel;
    }

    private JPanel createDecryptionPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE), "GIẢI MÃ", TitledBorder.LEFT, TitledBorder.TOP, null, Color.BLUE));

        // Khóa bí mật
        JPanel pnlKey = new JPanel(new BorderLayout());
        pnlKey.add(new JLabel("Khóa bí mật:"), BorderLayout.NORTH);
        txtKeyDec = new JTextArea(5, 15);
        txtKeyDec.setLineWrap(true);
        pnlKey.add(new JScrollPane(txtKeyDec), BorderLayout.CENTER);

        // Bản mã đầu vào
        JPanel pnlCipher = new JPanel(new BorderLayout());
        pnlCipher.add(new JLabel("Bản mã (Nhập Text):"), BorderLayout.NORTH);
        txtCiphertextDec = new JTextArea();
        txtCiphertextDec.setLineWrap(true);
        pnlCipher.add(new JScrollPane(txtCiphertextDec), BorderLayout.CENTER);

        JPanel pnlCipherBtns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnDecryptText = new JButton("Giải mã Text");
        JButton btnDecryptFile = new JButton("Giải mã File"); // NÚT MỚI
        pnlCipherBtns.add(btnDecryptText);
        pnlCipherBtns.add(btnDecryptFile);
        pnlCipher.add(pnlCipherBtns, BorderLayout.SOUTH);

        // Bản rõ đầu ra
        JPanel pnlPlain = new JPanel(new BorderLayout());
        pnlPlain.add(new JLabel("Bản rõ:"), BorderLayout.NORTH);
        txtPlaintextDec = new JTextArea();
        txtPlaintextDec.setLineWrap(true);
        pnlPlain.add(new JScrollPane(txtPlaintextDec), BorderLayout.CENTER);

        JPanel pnlPlainBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnClear = new JButton("Xóa");
        JButton btnSaveFile = new JButton("Lưu Text");
        pnlPlainBtns.add(btnClear);
        pnlPlainBtns.add(btnSaveFile);
        pnlPlain.add(pnlPlainBtns, BorderLayout.SOUTH);

        // Định dạng
        JPanel pnlFormat = new JPanel(new GridLayout(3, 1));
        pnlFormat.add(new JLabel("Định dạng đầu vào:"));
        rbHexDec = new JRadioButton("HEX", true);
        rbBase64Dec = new JRadioButton("BASE64");
        ButtonGroup bgDec = new ButtonGroup();
        bgDec.add(rbHexDec);
        bgDec.add(rbBase64Dec);
        pnlFormat.add(rbHexDec);
        pnlFormat.add(rbBase64Dec);
        pnlKey.add(pnlFormat, BorderLayout.EAST);

        // Layout tổng
        JPanel centerPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        centerPanel.add(pnlCipher);
        centerPanel.add(pnlPlain);

        panel.add(pnlKey, BorderLayout.WEST);
        panel.add(centerPanel, BorderLayout.CENTER);

        // Events
        btnDecryptText.addActionListener(e -> decryptText());
        btnDecryptFile.addActionListener(e -> processFile(Cipher.DECRYPT_MODE, txtKeyDec.getText().trim()));
        btnClear.addActionListener(e -> { txtCiphertextDec.setText(""); txtPlaintextDec.setText(""); });
        btnSaveFile.addActionListener(e -> saveTextFile(txtPlaintextDec));

        return panel;
    }

    private void generateKey() {
        try {
            KeyGenerator keyGen = KeyGenerator.getInstance("DES");
            SecretKey secretKey = keyGen.generateKey();
            String hexKey = bytesToHex(secretKey.getEncoded());
            txtKeyEnc.setText(hexKey.toUpperCase());
            txtKeyDec.setText(hexKey.toUpperCase());
            JOptionPane.showMessageDialog(this, "Khóa đã được tạo thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // --- XỬ LÝ MÃ HÓA/GIẢI MÃ ĐOẠN TEXT BÌNH THƯỜNG ---
    private void encryptText() {
        String key = txtKeyEnc.getText().trim();
        String plainText = txtPlaintext.getText();

        if (plainText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập bản rõ!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (key.length() != 16) { 
            JOptionPane.showMessageDialog(this, "Khóa không hợp lệ! Vui lòng kiểm tra lại độ dài khóa!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
            SecretKeySpec secretKey = new SecretKeySpec(hexToBytes(key), "DES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedBytes = cipher.doFinal(plainText.getBytes("UTF-8"));

            if (rbHexEnc.isSelected()) {
                txtCiphertextEnc.setText(bytesToHex(encryptedBytes).toUpperCase());
            } else {
                txtCiphertextEnc.setText(Base64.getEncoder().encodeToString(encryptedBytes));
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi mã hóa: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void decryptText() {
        String key = txtKeyDec.getText().trim();
        String cipherText = txtCiphertextDec.getText().trim();

        if (key.length() != 16) {
            JOptionPane.showMessageDialog(this, "Khóa bị thay đổi! Vui lòng kiểm tra lại kích thước và nội dung khóa!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            byte[] cipherBytes;
            if (rbHexDec.isSelected()) {
                cipherBytes = hexToBytes(cipherText);
            } else {
                cipherBytes = Base64.getDecoder().decode(cipherText);
            }

            Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
            SecretKeySpec secretKey = new SecretKeySpec(hexToBytes(key), "DES");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            
            byte[] decryptedBytes = cipher.doFinal(cipherBytes);
            txtPlaintextDec.setText(new String(decryptedBytes, "UTF-8"));
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Dữ liệu không toàn vẹn! Lỗi giải mã: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

 // --- CHỨC NĂNG MỚI: XỬ LÝ MÃ HÓA/GIẢI MÃ TỆP TIN (FILE) TRỰC TIẾP ---
    private void processFile(int mode, String keyString) {
        if (keyString.length() != 16) {
            JOptionPane.showMessageDialog(this, "Khóa không hợp lệ! Khóa phải đủ 16 ký tự HEX.", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(mode == Cipher.ENCRYPT_MODE ? "Chọn file để mã hóa" : "Chọn file để giải mã");
        
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File inputFile = fileChooser.getSelectedFile();
            
            JFileChooser saveChooser = new JFileChooser();
            saveChooser.setDialogTitle("Lưu file kết quả");
            String defaultSuffix = mode == Cipher.ENCRYPT_MODE ? ".enc" : ".dec";
            saveChooser.setSelectedFile(new File(inputFile.getAbsolutePath() + defaultSuffix));
            
            if (saveChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                File outputFile = saveChooser.getSelectedFile();
                
                try {
                    // Đọc toàn bộ byte của file vào bộ nhớ
                    byte[] fileBytes = Files.readAllBytes(inputFile.toPath());
                    
                    // Thiết lập thuật toán DES
                    Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
                    SecretKeySpec secretKey = new SecretKeySpec(hexToBytes(keyString), "DES");
                    cipher.init(mode, secretKey);
                    
                    // Xử lý mã hóa hoặc giải mã
                    byte[] outputBytes = cipher.doFinal(fileBytes);
                    
                    // Lưu file kết quả chính (File nhị phân dùng để giải mã)
                    Files.write(outputFile.toPath(), outputBytes);
                    
                    // NÂNG CẤP BỔ SUNG: Nếu đang MÃ HÓA, tạo thêm 1 file TXT để người dùng "xem" được mã HEX
                    if (mode == Cipher.ENCRYPT_MODE) {
                        String hexOutput = bytesToHex(outputBytes);
                        File viewableFile = new File(outputFile.getAbsolutePath() + "_XEM_THU.txt");
                        Files.write(viewableFile.toPath(), hexOutput.getBytes("UTF-8"));
                        
                        JOptionPane.showMessageDialog(this, 
                            "Mã hóa file thành công!\n" +
                            "1. File để giải mã: " + outputFile.getName() + "\n" +
                            "2. File để xem mã: " + viewableFile.getName(), 
                            "Thành công", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(this, "Giải mã file thành công!\nĐã lưu tại: " + outputFile.getAbsolutePath(), "Thành công", JOptionPane.INFORMATION_MESSAGE);
                    }
                    
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Có lỗi xảy ra: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private void saveTextFile(JTextArea sourceArea) {
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                File file = fileChooser.getSelectedFile();
                Files.write(file.toPath(), sourceArea.getText().getBytes("UTF-8"));
                JOptionPane.showMessageDialog(this, "Lưu file thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Không thể lưu file!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Helper methods for HEX conversions
    private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }

    public static byte[] hexToBytes(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                                 + Character.digit(s.charAt(i+1), 16));
        }
        return data;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) { e.printStackTrace(); }
            new DESEncryptionApp().setVisible(true);
        });
    }
}