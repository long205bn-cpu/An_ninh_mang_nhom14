﻿using System;
using System.IO;
using System.Text;
using System.Windows;
using Microsoft.Win32;

namespace ThuatToanDES
{
    public partial class MainWindow : Window
    {
        private DESAlgorithm des = new DESAlgorithm();

        // Lưu file đang mở
        private string currentFilePath = "";

        public MainWindow()
        {
            InitializeComponent();
        }

        // ==========================
        // MÃ HÓA
        // ==========================
        private void btnEncrypt_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtInput.Text))
                {
                    MessageBox.Show(
                        "Vui lòng nhập dữ liệu cần mã hóa!");
                    return;
                }

                if (txtKey.Text.Length != 8)
                {
                    MessageBox.Show(
                        "Khóa DES phải đúng 8 ký tự!");
                    return;
                }

                string cipher =
                    des.Encrypt(
                        txtInput.Text,
                        txtKey.Text);

                txtOutput.Text = cipher;
                if (!string.IsNullOrEmpty(currentFilePath))
                {
                    string encryptedFile =
                        Path.Combine(
                            Path.GetDirectoryName(currentFilePath)!,
                            "Encrypted.txt");

                    File.WriteAllText(
                        encryptedFile,
                        cipher,
                        Encoding.UTF8);
                }

                txtHex.Text =
                    ConvertToHex(cipher);

                txtIP.Text = "Đã thực hiện IP";
                txtIP1.Text = "Đã thực hiện IP⁻¹";

                dgRounds.ItemsSource = null;
                dgRounds.ItemsSource = des.Rounds;

                MessageBox.Show(
                    "Mã hóa thành công!",
                    "DES",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Lỗi mã hóa",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // ==========================
        // GIẢI MÃ
        // ==========================
        private void btnDecrypt_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtInput.Text))
                {
                    MessageBox.Show(
                        "Vui lòng nhập dữ liệu cần giải mã!");
                    return;
                }

                if (txtKey.Text.Length != 8)
                {
                    MessageBox.Show(
                        "Khóa DES phải đúng 8 ký tự!");
                    return;
                }

                string plainText =
                    des.Decrypt(
                        txtInput.Text,
                        txtKey.Text);

                txtOutput.Text = plainText;
                if (!string.IsNullOrEmpty(currentFilePath))
                {
                    string decryptedFile =
                        Path.Combine(
                            Path.GetDirectoryName(currentFilePath)!,
                            "Decrypted.txt");

                    File.WriteAllText(
                        decryptedFile,
                        plainText,
                        Encoding.UTF8);
                }

                txtHex.Text =
                    ConvertToHex(plainText);

                dgRounds.ItemsSource = null;
                dgRounds.ItemsSource = des.Rounds;

                MessageBox.Show(
                    "Giải mã thành công!",
                    "DES",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Lỗi giải mã",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // ==========================
        // XÓA
        // ==========================
        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            txtInput.Clear();
            txtOutput.Clear();
            txtHex.Clear();
            txtIP.Clear();
            txtIP1.Clear();

            currentFilePath = "";

            dgRounds.ItemsSource = null;
        }

        // ==========================
        // MỞ FILE
        // ==========================
        private void btnOpen_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dialog =
                    new OpenFileDialog();

                dialog.Title =
                    "Chọn file dữ liệu";

                dialog.Filter =
                    "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";

                if (dialog.ShowDialog() == true)
                {
                    currentFilePath =
                        dialog.FileName;

                    txtInput.Text =
                        File.ReadAllText(
                            currentFilePath,
                            Encoding.UTF8);

                    MessageBox.Show(
                        "Đã tải file thành công!",
                        "DES",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Lỗi mở file",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // ==========================
        // LƯU FILE
        // ==========================
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtOutput.Text))
                {
                    MessageBox.Show(
                        "Không có dữ liệu để lưu!");
                    return;
                }

                SaveFileDialog dialog =
                    new SaveFileDialog();

                dialog.Title =
                    "Lưu kết quả DES";

                dialog.Filter =
                    "Text Files (*.txt)|*.txt";

                dialog.FileName =
                    "DES_Result.txt";

                if (dialog.ShowDialog() == true)
                {
                    StringBuilder builder =
                        new StringBuilder();

                    builder.AppendLine("===== KẾT QUẢ DES =====");
                    builder.AppendLine();

                    builder.AppendLine("INPUT:");
                    builder.AppendLine(txtInput.Text);
                    builder.AppendLine();

                    builder.AppendLine("KEY:");
                    builder.AppendLine(txtKey.Text);
                    builder.AppendLine();

                    builder.AppendLine("OUTPUT:");
                    builder.AppendLine(txtOutput.Text);
                    builder.AppendLine();

                    builder.AppendLine("HEX:");
                    builder.AppendLine(txtHex.Text);
                    builder.AppendLine();

                    builder.AppendLine("IP:");
                    builder.AppendLine(txtIP.Text);
                    builder.AppendLine();

                    builder.AppendLine("IP-1:");
                    builder.AppendLine(txtIP1.Text);

                    File.WriteAllText(
                        dialog.FileName,
                        builder.ToString(),
                        Encoding.UTF8);

                    MessageBox.Show(
                        "Lưu file thành công!",
                        "DES",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Lỗi lưu file",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // ==========================
        // CHUYỂN HEX
        // ==========================
        private string ConvertToHex(string input)
        {
            if (string.IsNullOrEmpty(input))
                return "";

            byte[] bytes =
                Encoding.UTF8.GetBytes(input);

            return BitConverter
                .ToString(bytes)
                .Replace("-", " ");
        }
    }
}