﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace ThuatToanDES
{
    public class DESAlgorithm
    {
        public List<DESRound> Rounds = new List<DESRound>();

        public string Encrypt(string text, string key)
        {
            Rounds.Clear();

            for (int i = 1; i <= 16; i++)
            {
                Rounds.Add(new DESRound
                {
                    Round = i,
                    Left = $"L{i - 1}",
                    Right = $"R{i - 1}",
                    RoundKey = $"K{i}",
                    FunctionResult = $"f(R{i - 1},K{i})"
                });
            }

            using (DESCryptoServiceProvider des =
                   new DESCryptoServiceProvider())
            {
                des.Key = Encoding.UTF8.GetBytes(key);
                des.IV = Encoding.UTF8.GetBytes(key);

                byte[] data = Encoding.UTF8.GetBytes(text);

                ICryptoTransform encryptor =
                    des.CreateEncryptor();

                byte[] result =
                    encryptor.TransformFinalBlock(
                        data,
                        0,
                        data.Length);

                return Convert.ToBase64String(result);
            }
        }

        public string Decrypt(string cipher, string key)
        {
            using (DESCryptoServiceProvider des =
                   new DESCryptoServiceProvider())
            {
                des.Key = Encoding.UTF8.GetBytes(key);
                des.IV = Encoding.UTF8.GetBytes(key);

                byte[] data =
                    Convert.FromBase64String(cipher);

                ICryptoTransform decryptor =
                    des.CreateDecryptor();

                byte[] result =
                    decryptor.TransformFinalBlock(
                        data,
                        0,
                        data.Length);

                return Encoding.UTF8.GetString(result);
            }
        }

        public void EncryptFile(
            string inputFile,
            string outputFile,
            string key)
        {
            string content =
                File.ReadAllText(
                    inputFile,
                    Encoding.UTF8);

            string cipher =
                Encrypt(content, key);

            File.WriteAllText(
                outputFile,
                cipher,
                Encoding.UTF8);
        }

        public void DecryptFile(
            string inputFile,
            string outputFile,
            string key)
        {
            string cipher =
                File.ReadAllText(
                    inputFile,
                    Encoding.UTF8);

            string plain =
                Decrypt(cipher, key);

            File.WriteAllText(
                outputFile,
                plain,
                Encoding.UTF8);
        }
    }
}