﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThuatToanDES
{
    public class DESRound
    {
        public int Round { get; set; }

        public string Left { get; set; }

        public string Right { get; set; }

        public string RoundKey { get; set; }

        public string FunctionResult { get; set; }
    }
}